export interface Enrollment {
    _id: string;
    user: string;
    course: string;
}
