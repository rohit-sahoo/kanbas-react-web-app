export interface Lesson {
    _id: String;
    name: String;
    description: String;
    module: String;
    indent: Number
}